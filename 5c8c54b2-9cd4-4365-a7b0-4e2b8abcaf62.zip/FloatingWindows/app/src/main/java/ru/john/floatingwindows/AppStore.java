package ru.john.floatingwindows;
import android.content.*;
import android.content.pm.*;
import java.util.*;

final class AppStore {
    static android.content.SharedPreferences prefs(Context c) { return c.getSharedPreferences("sidebar", Context.MODE_PRIVATE); }
    static List<ResolveInfo> apps(Context c) {
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> r = new ArrayList<>(c.getPackageManager().queryIntentActivities(i, 0));
        r.removeIf(a -> a.activityInfo.packageName.equals(c.getPackageName()));
        r.sort((a,b) -> String.valueOf(a.loadLabel(c.getPackageManager())).compareToIgnoreCase(String.valueOf(b.loadLabel(c.getPackageManager()))));
        Set<String> unique = new HashSet<>();
        r.removeIf(a -> !unique.add(a.activityInfo.packageName));
        return r;
    }
    static List<String> selected(Context c) {
        android.content.SharedPreferences s = prefs(c);
        if (!s.contains("selected")) {
            List<String> defaults = new ArrayList<>();
            for (ResolveInfo a : apps(c)) {
                String text = (a.activityInfo.packageName + " " + a.loadLabel(c.getPackageManager())).toLowerCase(Locale.ROOT);
                if (text.contains("kernelsu") || text.contains("telegram") || text.contains("телеграм") || text.contains("bin.mt.plus") || text.contains("mt manager") || text.contains("tiktok") || text.contains("musically") || text.contains("messenger") || text.contains("мессенджер") || text.contains("happ") || text.contains("proxy") || text.contains("прокси") || a.activityInfo.packageName.equals("ru.oneme.app")) defaults.add(a.activityInfo.packageName);
            }
            save(c, defaults);
        }
        List<String> out = new ArrayList<>();
        for (String v : s.getString("selected", "").split("\\|")) if (!v.isEmpty()) out.add(v);
        return out;
    }
    static void save(Context c,List<String> names) { prefs(c).edit().putString("selected", String.join("|", names)).apply(); }
}
