package ru.john.floatingwindows;
import android.app.*;
import android.content.*;
import android.content.pm.ResolveInfo;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class SidebarService extends Service {
    private WindowManager wm;
    private View handle;
    private LinearLayout panel;
    private WindowManager.LayoutParams handleParams,panelParams;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private boolean opened=false,animating=false;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private Rect bounds(){return wm.getCurrentWindowMetrics().getBounds();}
    private int screenH(){return bounds().height();}
    private int panelH(){return Math.min(dp(480),screenH()-dp(120));}
    private int panelY(){return Math.max(dp(36),Math.min(handleParams.y-dp(40),screenH()-panelH()-dp(36)));}
    private GradientDrawable bg(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);}
    @Override public int onStartCommand(Intent intent,int flags,int id){
        if(intent!=null&&"stop".equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("sidebar","Боковая панель",NotificationManager.IMPORTANCE_LOW));
        PendingIntent settings=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop=PendingIntent.getService(this,2,new Intent(this,SidebarService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification note=new Notification.Builder(this,"sidebar").setSmallIcon(ru.john.floatingwindows.R.drawable.ic_app).setContentTitle("Плавающие окна").setContentText("Полоска слева · потяни вправо").setContentIntent(settings).setOngoing(true).addAction(new Notification.Action.Builder(null,"Выключить",stop).build()).build();
        startForeground(1,note);
        try { if(handle==null) addHandle();if(opened)fillPanel();AppStore.prefs(this).edit().putBoolean("enabled",true).apply(); }
        catch(Exception e){Toast.makeText(this,"Не удалось показать панель: "+e.getMessage(),Toast.LENGTH_LONG).show();stopSelf();}
        return START_NOT_STICKY;
    }
    private WindowManager.LayoutParams params(int w,int h){
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.LEFT;return p;
    }
    private void addHandle(){
        FrameLayout touch=new FrameLayout(this);
        View line=new View(this);line.setBackground(bg(0xff79b5ff,8));FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(4),dp(64),Gravity.CENTER);touch.addView(line,lp);
        touch.setContentDescription("Открыть панель. Потяни вправо, вверх или вниз.");
        handle=touch;handleParams=params(dp(24),dp(96));handleParams.y=Math.max(dp(36),Math.min(AppStore.prefs(this).getInt("handle_y",screenH()/3),screenH()-dp(132)));
        touch.setOnTouchListener(new View.OnTouchListener(){float x,y;int oldY;boolean moved;
            public boolean onTouch(View v,android.view.MotionEvent e){
                switch(e.getActionMasked()){
                    case MotionEvent.ACTION_DOWN:x=e.getRawX();y=e.getRawY();oldY=handleParams.y;moved=false;return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx=e.getRawX()-x,dy=e.getRawY()-y;
                        if(dx>dp(26)&&Math.abs(dx)>Math.abs(dy)){showPanel();moved=true;}
                        else if(Math.abs(dy)>dp(10)){moved=true;handleParams.y=Math.max(dp(36),Math.min(oldY+(int)dy,screenH()-dp(132)));wm.updateViewLayout(handle,handleParams);if(opened){panelParams.y=panelY();wm.updateViewLayout(panel,panelParams);}}
                        return true;
                    case MotionEvent.ACTION_UP:AppStore.prefs(SidebarService.this).edit().putInt("handle_y",handleParams.y).apply();if(!moved){v.performClick();showPanel();}return true;
                    case MotionEvent.ACTION_CANCEL:return true;
                }return false;
            }
        });
        wm.addView(handle,handleParams);
    }
    private void showPanel(){
        if(opened||animating)return;
        panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(8),dp(8),dp(8),dp(8));panel.setBackground(bg(0xf2262c35,24));panel.setElevation(dp(8));
        panelParams=params(dp(88),panelH());panelParams.x=-dp(96);panelParams.y=panelY();panelParams.flags|=WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
        panel.setOnTouchListener((v,e)->{if(e.getActionMasked()==MotionEvent.ACTION_OUTSIDE){hidePanel();return true;}return false;});
        fillPanel();wm.addView(panel,panelParams);opened=true;animate(-dp(96),dp(8),false);
    }
    private void animate(int from,int to,boolean remove){
        animating=true;android.animation.ValueAnimator a=android.animation.ValueAnimator.ofInt(from,to);a.setDuration(220);a.setInterpolator(new android.view.animation.DecelerateInterpolator());
        a.addUpdateListener(v->{if(panel!=null){panelParams.x=(int)v.getAnimatedValue();try{wm.updateViewLayout(panel,panelParams);}catch(Exception ignored){}}});
        a.addListener(new android.animation.AnimatorListenerAdapter(){@Override public void onAnimationEnd(android.animation.Animator a){animating=false;if(remove)removePanel();}});a.start();
    }
    private void hidePanel(){if(opened&&!animating)animate(panelParams.x,-dp(96),true);}
    private void removePanel(){if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;}opened=false;}
    private void fillPanel(){
        if(panel==null)return;panel.removeAllViews();
        ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);LinearLayout icons=new LinearLayout(this);icons.setOrientation(1);scroll.addView(icons);
        panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        List<String> selected=AppStore.selected(this);Map<String,ResolveInfo> all=new HashMap<>();for(ResolveInfo r:AppStore.apps(this))all.put(r.activityInfo.packageName,r);
        for(String pkg:selected){ResolveInfo r=all.get(pkg);if(r==null)continue;
            CircleIcon icon=new CircleIcon(this,r.loadIcon(getPackageManager()),String.valueOf(r.loadLabel(getPackageManager())));
            icons.addView(icon,new LinearLayout.LayoutParams(-1,dp(64)));icon.setOnClickListener(v->{hidePanel();launch(r);});
            icon.setOnLongClickListener(v->{List<String> names=AppStore.selected(this);names.remove(pkg);AppStore.save(this,names);fillPanel();Toast.makeText(this,"Убрано из панели — приложение не удалено",Toast.LENGTH_SHORT).show();return true;});
        }
        TextView plus=new TextView(this);plus.setText("+");plus.setTextSize(32);plus.setTextColor(Color.WHITE);plus.setGravity(Gravity.CENTER);plus.setContentDescription("Добавить приложения");panel.addView(plus,new LinearLayout.LayoutParams(-1,dp(56)));
        plus.setOnClickListener(v->{hidePanel();startActivity(new Intent(this,MainActivity.class).putExtra("picker",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));});
        TextView close=new TextView(this);close.setText("‹");close.setTextSize(28);close.setTextColor(0xffb6b6b6);close.setGravity(Gravity.CENTER);close.setContentDescription("Свернуть панель");panel.addView(close,new LinearLayout.LayoutParams(-1,dp(44)));close.setOnClickListener(v->hidePanel());
    }
    private void launch(ResolveInfo r){
        ComponentName component=new ComponentName(r.activityInfo.packageName,r.activityInfo.name);
        if(!AppStore.prefs(this).getBoolean("root",true)){
            try{startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(component).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}return;
        }
        Root.WORKER.execute(()->{
            Root.Result result=Root.run("am start --user current --windowingMode 5 -n "+Root.quote(component.flattenToString()));
            ui.post(()->Toast.makeText(this,result.ok()?"Запрос окна отправлен. Полный экран означает, что HyperOS не разрешила этот режим.":"Не удалось открыть окно. Проверь KernelSU.\n"+result.text,Toast.LENGTH_LONG).show());
        });
    }
    @Override public void onConfigurationChanged(android.content.res.Configuration config){super.onConfigurationChanged(config);removePanel();if(handle!=null){handleParams.y=Math.max(dp(36),Math.min(handleParams.y,screenH()-dp(132)));wm.updateViewLayout(handle,handleParams);}}
    @Override public void onDestroy(){removePanel();if(handle!=null){try{wm.removeView(handle);}catch(Exception ignored){}handle=null;}AppStore.prefs(this).edit().putBoolean("enabled",false).apply();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
