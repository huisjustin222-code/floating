package ru.john.floatingwindows;
import java.io.*;
import java.util.concurrent.*;

final class Root {
    static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    static final class Result {
        final int code; final String text;
        Result(int code,String text) { this.code=code; this.text=text; }
        boolean ok() { return code==0 && !text.contains("Error:") && !text.contains("Exception"); }
    }
    // Command arguments are shell-quoted. Never execute labels or user input.
    static String quote(String s) { return "'"+s.replace("'", "'\\''")+"'"; }
    static Result run(String command) {
        Process proc=null;
        try {
            proc = new ProcessBuilder("su", "-c", command).redirectErrorStream(true).start();
            final Process reading=proc;
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            Thread reader=new Thread(() -> {
                try (InputStream in=reading.getInputStream()) {
                    byte[] b=new byte[2048]; int n;
                    while ((n=in.read(b))!=-1) { synchronized(bytes) { if(bytes.size()<65536) bytes.write(b,0,Math.min(n,65536-bytes.size())); } }
                } catch(IOException ignored) {}
            });
            reader.setDaemon(true); reader.start();
            if(!proc.waitFor(45,TimeUnit.SECONDS)) { proc.destroyForcibly(); return new Result(-1,"Истекло время ожидания KernelSU"); }
            reader.join(1000);
            synchronized(bytes) { return new Result(proc.exitValue(),bytes.toString("UTF-8").trim()); }
        } catch(Exception e) { return new Result(-1,e.toString()); }
        finally { if(proc!=null) proc.destroy(); }
    }
}
