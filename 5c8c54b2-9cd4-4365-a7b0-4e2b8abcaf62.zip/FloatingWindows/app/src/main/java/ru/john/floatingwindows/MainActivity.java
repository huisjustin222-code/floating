package ru.john.floatingwindows;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.content.pm.ResolveInfo;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout content;
    private TextView state;
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(Color.rgb(25,25,25));
        content=new LinearLayout(this);content.setOrientation(1);content.setPadding(dp(24),dp(24),dp(24),dp(32));scroll.addView(content);
        scroll.setOnApplyWindowInsetsListener((v,insets)-> {
            android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            content.setPadding(dp(24)+bars.left,dp(24)+bars.top,dp(24)+bars.right,dp(32)+bars.bottom);return insets;
        });
        setContentView(scroll);
        text("Плавающие\nокна",32,Color.WHITE);
        text("Твоя маленькая панель больших дел",16,0xffb6b6b6);
        state=text("",16,0xff72bc8f);
        button("1 · Разрешить поверх приложений",()->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
        button("2 · Проверить KernelSU",()->work("id",r -> dialog("KernelSU",r.ok()&&r.text.contains("uid=0") ? "Root доступен. Разреши постоянный доступ для «Плавающие окна» в KernelSU." : "Root не подтверждён. Проверь разрешение в KernelSU.\n\n"+r.text)));
        Switch root=new Switch(this);root.setText("Открывать через root в свободном окне");root.setTextColor(Color.WHITE);root.setPadding(0,dp(16),0,dp(16));root.setChecked(AppStore.prefs(this).getBoolean("root",true));root.setOnCheckedChangeListener((v,on)->AppStore.prefs(this).edit().putBoolean("root",on).apply());content.addView(root);
        text("Экспериментально: HyperOS может игнорировать запрос. В выключенном режиме приложения открываются обычно, на весь экран.",14,0xffb6b6b6);
        button("Выбрать приложения  +",this::chooseApps);
        button("Включить левую панель",()-> {
            if(!Settings.canDrawOverlays(this)) { dialog("Нужно разрешение","Сначала разреши отображение поверх других приложений.");return; }
            if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4);
            try { startForegroundService(new Intent(this,SidebarService.class));AppStore.prefs(this).edit().putBoolean("enabled",true).apply();refresh(); }
            catch(Exception e) { dialog("Не удалось включить",e.toString()); }
        });
        button("Выключить панель",()->{stopService(new Intent(this,SidebarService.class));AppStore.prefs(this).edit().putBoolean("enabled",false).apply();refresh();});
        text("Потяни полоску вправо. Потяни саму полоску вверх или вниз, чтобы поменять её положение. Нажми значок для запуска, удерживай — чтобы убрать его из панели. «+» открывает выбор приложений.",16,0xffb6b6b6);
        button("Экспериментальные настройки окон",()->new AlertDialog.Builder(this).setTitle("Изменить системные настройки?").setMessage("Будут включены enable_freeform_support и force_resizable_activities через root. Это системные настройки: они могут изменить поведение других приложений. Исходные значения сохраняются для отмены. Может понадобиться перезагрузка. Это не гарантирует окна в HyperOS. Системные файлы не меняются.").setNegativeButton("Отмена",null).setPositiveButton("Включить",(d,w)->enableFreeform()).show());
        button("Вернуть исходные настройки окон",()->restoreFreeform());
        text("POCO M7 · Android 16\nВерсия 0.1 · Без LSPosed\nПосле перезагрузки включи панель вручную. В HyperOS разреши автозапуск и сними ограничения батареи, если панель исчезает.",14,0xffb6b6b6);
        refresh();
        if(getIntent().getBooleanExtra("picker",false)) chooseApps();
    }
    private TextView text(String s,int size,int color) {TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,dp(8),0,dp(12));content.addView(t);return t;}
    private void button(String label,Runnable action) {
        Button b=new Button(this); b.setAllCaps(false);b.setText(label);b.setTextSize(16);b.setTextColor(Color.WHITE);
        GradientDrawable bg=new GradientDrawable();bg.setColor(0xff263545);bg.setCornerRadius(dp(12));b.setBackground(bg);b.setPadding(dp(16),dp(12),dp(16),dp(12));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(8));content.addView(b,lp);b.setOnClickListener(v->action.run());
    }
    @Override public void onResume(){super.onResume();if(state!=null)refresh();}
    private void refresh(){state.setText(AppStore.prefs(this).getBoolean("enabled",false)?"● Панель включена":"○ Панель выключена");}
    private void dialog(String title,String msg){if(!isFinishing()&&!isDestroyed())new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("Ок",null).show();}
    private interface Callback{void done(Root.Result r);}
    private void work(String cmd,Callback cb){Toast.makeText(this,"Ожидаю KernelSU…",Toast.LENGTH_SHORT).show();Root.WORKER.execute(()->{Root.Result r=Root.run(cmd);runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())cb.done(r);});});}
    private void chooseApps(){
        List<ResolveInfo> list=AppStore.apps(this);List<String> selected=AppStore.selected(this);
        String[] labels=new String[list.size()];boolean[] checked=new boolean[list.size()];
        for(int i=0;i<list.size();i++){labels[i]=String.valueOf(list.get(i).loadLabel(getPackageManager()));checked[i]=selected.contains(list.get(i).activityInfo.packageName);}
        new AlertDialog.Builder(this).setTitle("Приложения в панели").setMultiChoiceItems(labels,checked,(d,i,on)->checked[i]=on).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{
            List<String> names=new ArrayList<>(); for(int i=0;i<list.size();i++)if(checked[i])names.add(list.get(i).activityInfo.packageName);AppStore.save(this,names);
            if(AppStore.prefs(this).getBoolean("enabled",false)&&Settings.canDrawOverlays(this)) startForegroundService(new Intent(this,SidebarService.class).setAction("refresh"));
        }).show();
    }
    private void enableFreeform(){
        Root.WORKER.execute(()->{
            android.content.SharedPreferences prefs=AppStore.prefs(this);
            if(!prefs.contains("old_freeform")) {
                Root.Result a=Root.run("settings get global enable_freeform_support"),b=Root.run("settings get global force_resizable_activities");
                if(!a.ok()||!b.ok()||!valid(a.text)||!valid(b.text)){runOnUiThread(()->dialog("Ошибка","Не удалось безопасно сохранить исходные значения."));return;}
                prefs.edit().putString("old_freeform",a.text).putString("old_resize",b.text).commit();
            }
            Root.Result r=Root.run("settings put global enable_freeform_support 1 && settings put global force_resizable_activities 1");
            runOnUiThread(()->dialog("Настройки окон",r.ok()?"Настройки включены. Перезагрузи телефон вручную, если окна не открываются. Отмена доступна кнопкой ниже.":r.text));
        });
    }
    private boolean valid(String s){return s.equals("null")||s.matches("-?[0-9]+");}
    private String restoreCmd(String key,String value){return value.equals("null")?"settings delete global "+key:"settings put global "+key+" "+Root.quote(value);}
    private void restoreFreeform(){
        android.content.SharedPreferences p=AppStore.prefs(this);
        if(!p.contains("old_freeform")){dialog("Нет изменений","Сохранённых исходных настроек нет.");return;}
        new AlertDialog.Builder(this).setTitle("Вернуть настройки?").setMessage("Будут восстановлены значения, сохранённые до включения экспериментального режима.").setNegativeButton("Отмена",null).setPositiveButton("Вернуть",(d,w)->work(restoreCmd("enable_freeform_support",p.getString("old_freeform","null"))+" && "+restoreCmd("force_resizable_activities",p.getString("old_resize","null")),r->{if(r.ok())p.edit().remove("old_freeform").remove("old_resize").apply();dialog("Настройки",r.ok()?"Исходные значения восстановлены. Может понадобиться перезагрузка.":r.text);})).show();
    }
}
