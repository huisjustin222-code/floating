package ru.john.floatingwindows;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.view.View;

final class CircleIcon extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private Bitmap icon;
    CircleIcon(Context c, Drawable d, String label) {
        super(c); setContentDescription(label); setFocusable(true);
        icon=Bitmap.createBitmap(128,128,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(icon); d.setBounds(0,0,128,128); d.draw(canvas);
    }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float size=Math.min(getWidth(),getHeight())*.76f;
        float x=(getWidth()-size)/2, y=(getHeight()-size)/2;
        paint.setColor(Color.WHITE); canvas.drawCircle(getWidth()/2f,getHeight()/2f,size/2,paint);
        int layer=canvas.save(); Path clip=new Path();clip.addCircle(getWidth()/2f,getHeight()/2f,size/2,Path.Direction.CW);canvas.clipPath(clip);
        canvas.drawBitmap(icon,null,new RectF(x,y,x+size,y+size),paint);canvas.restoreToCount(layer);
    }
}
